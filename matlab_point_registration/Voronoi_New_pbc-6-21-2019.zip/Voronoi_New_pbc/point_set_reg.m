function [grid_reg, distance] = point_set_reg(nX, nY, nZ, nfft, natom, ...
    box_x, box_y, box_z, iatom, x, xyz, rXYZ, grid1, grid2, grid_reg, distance)

alpha = x(1);
beta  = x(2);
gamma = x(3);

% Roataion
Rz = [1 0 0; 0 cos(alpha) -sin(alpha); 0 sin(alpha) cos(alpha)];
Rx = [cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Ry = [cos(gamma) -sin(gamma) 0; sin(gamma) cos(gamma) 0; 0 0 1];


% rotate all grid2 points
% TR_grid2 = grid2 - rXYZ(iatom, :);
% TR_grid2 = (Rz*Rx*Ry*(TR_grid2)')';
% TR_grid2 = TR_grid2 + xyz(iatom, :);


%=====================================
% get the VC of iatom for system II 
%=====================================
fprintf('get VC for atom %d system 2...\n',iatom)
len2 = 0;
for i=1:nfft
    % get the cloest atom (consider PBC)
    old_dist = 100000;
    for iat = 1:natom
        [dist, imag] = get_dist_pbc(grid2(i,:),rXYZ(iat,:),box_x,box_y,box_z);
        if dist<old_dist
            near_atom = iat;
            imag_cell = imag;  % back up the PBC info of the cloest atom
            old_dist = dist;   % back up the dist for cloest atom
        end
    end
    
    if (near_atom == iatom)
        len2 = len2 + 1;
        iatomVX_Idx2(len2) = i;
        pt2_unitcell(len2,:) = grid2(i,:);
        pt2_vc(len2,1) = grid2(i,1) - imag_cell(1)*box_x;
        pt2_vc(len2,2) = grid2(i,2) - imag_cell(2)*box_y;
        pt2_vc(len2,3) = grid2(i,3) - imag_cell(3)*box_z;
    end
end
fprintf('len2: %d\n',len2);


%===================================================================
% loop over all pts (TR_gird2) of the VC of iatom in system2
% check if pt is also VC of iatom for system1?
% yes -- get the closet VC point of iatom form system 1
% no -- set pt to -1;
%===================================================================
dista = zeros(1, len2);
reg = zeros(1, len2);
nreg = 0;
nVC_system1 = 0;
max_distance = -1;
fprintf('system 2 -> number of points in the VC of iatom: %d\n',len2);
fprintf('registering system 2`s points in system I ...\n')

dx = box_x/nX;
dy = box_y/nY;
dz = box_z/nZ;

pt1_map = zeros([len2,3]);
pt1_map(:,:) = 9999.0;  % initialize it

for j=1:len2
    pt2(j,:) = pt2_vc(j,:) - rXYZ(iatom, :);
    pt2(j,:) = (Rz*Rx*Ry*pt2(j,:)')';
    pt2(j,:) = pt2(j,:) + xyz(iatom,:);
end 


nb=5;

% make the assigned matrix
xmin = min(floor(pt2(:,1)/dx)+1); xmax = max(floor(pt2(:,1)/dx)+1);
ymin = min(floor(pt2(:,2)/dy)+1); ymax = max(floor(pt2(:,2)/dy)+1);
zmin = min(floor(pt2(:,3)/dz)+1); zmax = max(floor(pt2(:,3)/dz)+1);

assigned = zeros([...
    xmax-xmin+2*nb+2,...
    ymax-ymin+2*nb+2,...
    zmax-zmin+2*nb+2]);


%=====================================
% map system 2's points to system 1
%=====================================
for j = 1:len2
    reg(j) = -1;
    dista(j) = 0;
    
    % test if pt2 belongs to the iatom in system 1. If image_cell > 0, pt2
    % is close to an atom in the images, rather than the unit cell.
    [vc_atom, image_cell, ~] = belong_vc(pt2(j,:), xyz, box_x, box_y, box_z);
    
    if (vc_atom == iatom && image_cell<0)
        nVC_system1 = nVC_system1 + 1;
        
        % Get the closest pt1 for pt2 (pt1 may be outside the unit cell)
        ix = floor(pt2(j,1)/dx)+1;
        iy = floor(pt2(j,2)/dy)+1;
        iz = floor(pt2(j,3)/dz)+1;
        
        % Find the point that is cloest to pt2.
        % We will test if this point is in the VC of iatom later.
        old_dist = 99999;
        found_match = false;
        
        % loop over nearby points to find the cloest one 
        % (this is just the greedy method)
        for i1=-nb:nb
            for i2=-nb:nb
                for i3=-nb:nb
                    pt1_test(1) = (ix + i1)*dx;
                    pt1_test(2) = (iy + i2)*dy;
                    pt1_test(3) = (iz + i3)*dz;
                    
                    id1 = ix-xmin+1+i1+nb+1;
                    id2 = iy-ymin+1+i2+nb+1;
                    id3 = iz-zmin+1+i3+nb+1;
                    
                    if assigned(id1,id2,id3) == 0 
                        dist = norm(pt1_test-pt2(j,:));
                        if old_dist > dist
                            id1_best = id1; id2_best = id2; id3_best = id3;
                            pt1_index = [ix+i1,iy+i2,iz+i3];                            
                            pt1_best = pt1_test;
                            old_dist = dist;
                            found_match = true;
                        end
                    end
                end
            end
        end
        
        if (found_match==false)
            fprintf('found_match is false! stop\n')
            stop
        end
        
        pt1_map(j,:) = pt1_best;
        assigned(id1_best,id2_best,id3_best) = 1;
        
        [vc_atom, image_cell, ~] = belong_vc(pt1_best, xyz, box_x, box_y, box_z);
        
        if (vc_atom == iatom && image_cell < 0)
            % pt1 is a point in the VC of iatom. Register it.
            nreg = nreg + 1;
            
            k1 = mod(pt1_index(1)-1,nX)+1;
            k2 = mod(pt1_index(2)-1,nY)+1;
            k3 = mod(pt1_index(3)-1,nZ)+1;
            
            reg(j) = k1 + (k2-1)*nX + (k3-1)*nX*nY;
            
            dista(j) = old_dist;
            
            if old_dist > max_distance
                max_distance = old_dist;
            end
        end
    end
end

fprintf('number of system II points inside the VC of system 1: %d\n',nVC_system1);
fprintf('number of registered points: %d\n',nreg);
fprintf('registration rate: %f %%. \n',nreg/(nVC_system1)*100);
fprintf('max distance between points in I and II: %f\n',max_distance);


% check the max mismatch 
if (max_distance>1.0)
    fprintf('max_distance > 0.5 too large! stop\n')
    stop
end

% check if we have duplicates in reg() array
for m=1:len2
    aa = reg(m);
    if aa==-1
        continue
    else
        for n=1:len2
            if aa==reg(n) && n~=m
                fprintf('found duplicates in reg() bug stop! index: %d, value: %d\n',n,reg(n))
                stop
            end
        end
    end
end



% %%%%%%%%%%%% plot system I and TR system II points together %%%%%%%%%%%%
% figure
% hold on
% 
% plot3(xyz(:, 1), xyz(:, 2), xyz(:, 3), 'ro','MarkerSize',15,'MarkerFaceColor','r')
% plot3(xyz(iatom, 1), xyz(iatom, 2), xyz(iatom, 3), 'ko','MarkerSize',15,'MarkerFaceColor','k')
% AAplot = zeros([nreg,3]);
% BBplot = zeros([nreg,3]);
% 
% c=0;
% for i = 1:length(reg)
%     if reg(i) == -1
%         continue
%     else
%         c = c+1;
%         AAplot(c,:) = TR_grid2(iatomVX_Idx2(i),:);
%         BBplot(c,:) = pt1_map(i,:);
%     end
% end
% plot3(AAplot(:,1),AAplot(:,2),AAplot(:,3),'kx','MarkerSize',5)
% plot3(BBplot(:,1),BBplot(:,2),BBplot(:,3),'bo','MarkerSize',5)
% for i=1:nreg
%     plot3([AAplot(i,1),BBplot(i,1)], ...
%         [AAplot(i,2),BBplot(i,2)], ...
%         [AAplot(i,3),BBplot(i,3)],'r-');
% end
% % xlim([0, box_x]);
% % ylim([0, box_y]);
% % zlim([0, box_z]);
% hold off
% 
% 
% 
% %%%%%%%%%%%% plot system I and un-rotated system II points together %%%%%%%%%%%%
% figure
% % xlim([0, box_x]);
% % ylim([0, box_y]);
% % zlim([0, box_z]);
% hold on
% plot3(xyz(:, 1),  xyz(:, 2),   xyz(:, 3), 'ro','MarkerSize',10,'MarkerFaceColor','r')
% plot3(xyz(iatom, 1),  xyz(iatom, 2),   xyz(iatom, 3), 'ro','MarkerSize',15,'MarkerFaceColor','r')
% plot3(rXYZ(:, 1), rXYZ(:, 2), rXYZ(:, 3), 'bo','MarkerSize',10,'MarkerFaceColor','b')
% plot3(rXYZ(iatom, 1), rXYZ(iatom, 2), rXYZ(iatom, 3), 'bo','MarkerSize',15,'MarkerFaceColor','b')
% for i = 1:length(reg)
%     if reg(i) == -1
%         continue
%     else
%         % system I
%         plot3(grid1(reg(i), 1), grid1(reg(i), 2), grid1(reg(i), 3), 'kx')
%         % system II
%         plot3(grid2(iatomVX_Idx2(i),1),grid2(iatomVX_Idx2(i),2),grid2(iatomVX_Idx2(i),3),'bo')
%     end
% end
% hold off


% recording grid_reg and distance 
for i = 1:length(reg)
    if (reg(i) ~= -1)
        grid_reg(iatomVX_Idx2(i)) = reg(i);
        distance(iatomVX_Idx2(i)) = dista(i);
    end
end

end