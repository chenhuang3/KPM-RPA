function [flag] = in_VC(iatom,pt,xyz,box_x,box_y,box_z)

len1 = 0;
flag = zeros([nfft,1]);
for i=1:nfft
    % get the cloest atom (consider PBC)
    old_dist = 100000;
    for iat = 1:natom
        dist = get_dist_pbc(grid1(i,:),xyz(iat,:),box_x,box_y,box_z);
        if dist<old_dist
            near_atom = iat;
            old_dist = dist;
        end
    end    
    if (near_atom == iatom)
        len1 = len1 + 1;
        flag(i) = 1;
    end
end
iatomVX_Idx1 = zeros([len1,1]);
counter = 0;
for i=1:nfft
    if flag(i)>0 
        counter = counter + 1;
        iatomVX_Idx1(counter) = i;
    end
end
fprintf('len1: %d\n',len1);

end