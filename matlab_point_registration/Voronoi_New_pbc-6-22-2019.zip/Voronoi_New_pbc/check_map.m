% check the maping %%%%%%%%%%%%%%%%%%%%%%
for i=1:nfft
    if grid_reg(i)~=-1        
        pt2 = grid2(i,:);
        pt1 = grid1(grid_reg(i),:);
        system2_d1 = norm(pt2-rXYZ(1,:));
        system2_d2 = norm(pt2-rXYZ(2,:));
        system1_d1 = norm(pt1-xyz(1,:));
        system1_d2 = norm(pt1-xyz(2,:));
    end
end