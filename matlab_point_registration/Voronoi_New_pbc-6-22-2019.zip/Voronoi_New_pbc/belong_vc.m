function [vc_atom,image_cell,dist] = belong_vc(pt, xyz, box_x, box_y, box_z)

%
% test if pt belong to the iatom's VC in system I
% if pt belongs to an atom in the images, image_cell will be set to 1
%

old_dist = 100000000;
natom = size(xyz,1);


 for imag1=-1:1
     for imag2=-1:1
         for imag3=-1:1
             for iat = 1:natom
                xatom(1) = xyz(iat,1) + imag1*box_x;
                xatom(2) = xyz(iat,2) + imag2*box_y;
                xatom(3) = xyz(iat,3) + imag3*box_z;
                dist = norm(pt - xatom);
                if dist < old_dist
                    if imag1 ~=0  || imag2~=0 || imag3 ~= 0
                        image_cell = 1;
                    end
                    if imag1==0 && imag2==0 && imag3==0
                        image_cell = -1;
                    end
                    old_dist = dist;
                    vc_atom = iat;
                end
            end
         end
     end
 end

dist = old_dist;
end