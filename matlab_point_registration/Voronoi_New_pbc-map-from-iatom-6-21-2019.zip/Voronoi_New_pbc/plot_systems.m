
%%%%%%%%%%%% plot system I and TR system II points together %%%%%%%%%%%%
figure
hold on

plot3(xyz(:, 1), xyz(:, 2), xyz(:, 3), 'ro','MarkerSize',15,'MarkerFaceColor','r')
plot3(xyz(iatom, 1), xyz(iatom, 2), xyz(iatom, 3), 'ko','MarkerSize',15,'MarkerFaceColor','k')
AAplot = zeros([nreg,3]);
BBplot = zeros([nreg,3]);

c=0;
for i = 1:length(reg)
    if reg(i) == -1
        continue
    else
        c = c+1;
        AAplot(c,:) = pt2_TR_sort(i,:);
        BBplot(c,:) = pt1_map(i,:);
    end
end
plot3(AAplot(:,1),AAplot(:,2),AAplot(:,3),'kx','MarkerSize',5)
plot3(BBplot(:,1),BBplot(:,2),BBplot(:,3),'bo','MarkerSize',5)
for i=1:nreg
    if norm(AAplot(i,:)-BBplot(i,:))>0.5
        plot3([AAplot(i,1),BBplot(i,1)], ...
            [AAplot(i,2),BBplot(i,2)], ...
            [AAplot(i,3),BBplot(i,3)],'r-');
    end
end
% xlim([0, box_x]);
% ylim([0, box_y]);
% zlim([0, box_z]);
hold off



%%%%%%%%%%%% plot system I and un-rotated system II points together %%%%%%%%%%%%
figure
% xlim([0, box_x]);
% ylim([0, box_y]);
% zlim([0, box_z]);
hold on
plot3(xyz(:, 1),  xyz(:, 2),   xyz(:, 3), 'ro','MarkerSize',10,'MarkerFaceColor','r')
plot3(xyz(iatom, 1),  xyz(iatom, 2),   xyz(iatom, 3), 'ro','MarkerSize',15,'MarkerFaceColor','r')
plot3(rXYZ(:, 1), rXYZ(:, 2), rXYZ(:, 3), 'bo','MarkerSize',10,'MarkerFaceColor','b')
plot3(rXYZ(iatom, 1), rXYZ(iatom, 2), rXYZ(iatom, 3), 'bo','MarkerSize',15,'MarkerFaceColor','b')
for i = 1:length(reg)
    if reg(i) == -1
        continue
    else
        % system I
        plot3(grid1(reg(i), 1), grid1(reg(i), 2), grid1(reg(i), 3), 'kx')
        % system II
        plot3(grid2(iatomVX_Idx2(i),1),grid2(iatomVX_Idx2(i),2),grid2(iatomVX_Idx2(i),3),'bo')
    end
end
legend('grid1','grid2')
hold off
