% for finding the bond length threshold
function [t ] = bond_threshold(type1, type2)

% define bond length
% Ref https://www.reed.edu/chemistry/roco/Geometry/bond_distances.html
bCN = 1.47 * 1.5;
bCC = 1.53 * 1.5;
bCO = 1.42 * 1.5;
bNH = 1.0 * 1.5;
bOH = 0.96 * 1.5;
bHH = 0.7 * 1.5;
bNO = 2.0 * 1.5;

if ((type1==1 && type2==8) || (type1==8 && type2==1))
    t = bOH;
elseif ((type1==1 && type2==1) || (type1==1 && type2==1))
    t = bHH;
elseif ((type1==7 && type2==1) || (type1==1 && type2==7))
    t = bNH;
elseif ((type1==6 && type2==8) || (type1==8 && type2==6))
    t = bCO;
elseif ((type1==6 && type2==6) || (type1==6 && type2==6))
    t= bCC;
elseif ((type1==6 && type2==7) || (type1==7 && type2==6))
    t= bCN;
elseif ((type1==8 && type2==7) || (type1==7 && type2==8))
    t = bNO;
else
    %type1
    %type2
    stop;
end
end
