%
% obtain the distance betwene a point (pt) and an atom (xatom)
% after considering the system is periodic, that is, the function 
% will return the cloest distance bewteen pt and one atom in the system
% the point (pt) is in the unit cell 
%
function [dist, imag] = get_dist_pbc(pt,xatom,box_x,box_y,box_z)


% pad the box in the -1, +1 in the x y z directions
dist = 1000000;

for i=-1:1
    for j=-1:1
        for k=-1:1
            d(1) = pt(1) - (xatom(1) + i*box_x);
            d(2) = pt(2) - (xatom(2) + j*box_y);
            d(3) = pt(3) - (xatom(3) + k*box_z);
            dist_tmp = norm(d);
            if (dist_tmp<dist)
                imag(1) = i;
                imag(2) = j;
                imag(3) = k;
                dist = dist_tmp;
            end
        end
    end
end



end 