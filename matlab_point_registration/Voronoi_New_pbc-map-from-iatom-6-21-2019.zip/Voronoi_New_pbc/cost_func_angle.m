function [c] = cost_func_angle(x)

global natom xyz rXYZ iatom natom_cluster buf_atoms

alpha = x(1);
beta = x(2);
gamma = x(3);

Rz = [1 0 0; 0 cos(alpha) -sin(alpha); 0 sin(alpha) cos(alpha)];
Rx = [cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Ry = [cos(gamma) -sin(gamma) 0; sin(gamma) cos(gamma) 0; 0 0 1];

% translate and rotate all the atoms from system 2
TR_xyz2 = zeros(natom, 3);

for i = 1:natom
    TR_xyz2(i,:) = rXYZ(i, :) - rXYZ(iatom, :);
    TR_xyz2(i,:) = (Rz*Rx*Ry*TR_xyz2(i,:)')';
    TR_xyz2(i,:) = TR_xyz2(i,:) + xyz(iatom,:);
end

% figure(3)
% plot3(TR_xyz2(:, 1), TR_xyz2(:, 2), TR_xyz2(:,3), 'r*','MarkerSize', 12)
% xlim([0, 14])
% ylim([0, 10])
% zlim([0, 10]);

c = 0.0;
for i = 1:natom_cluster
    k = buf_atoms(i);
    c = c + sqrt((xyz(k,1)-TR_xyz2(k,1))^2 ...
        + (xyz(k,2)-TR_xyz2(k,2))^2 ...
        + (xyz(k,3)-TR_xyz2(k,3))^2);
end


end





