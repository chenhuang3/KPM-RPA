function [grid_reg, distance] = point_set_reg(nX, nY, nZ, nfft, box_x, box_y, box_z, ...
    iatom, x, xyz, rXYZ, grid1, grid2, cutoff, grid_reg, distance)


fprintf('cutoff: %f\n',cutoff)

alpha = x(1);
beta  = x(2);
gamma = x(3);

% Roataion
Rz = [1 0 0; 0 cos(alpha) -sin(alpha); 0 sin(alpha) cos(alpha)];
Rx = [cos(beta) 0 sin(beta); 0 1 0; -sin(beta) 0 cos(beta)];
Ry = [cos(gamma) -sin(gamma) 0; sin(gamma) cos(gamma) 0; 0 0 1];


% rotate all grid2 points
TR_grid2 = grid2 - rXYZ(iatom, :);
TR_grid2 = (Rz*Rx*Ry*(TR_grid2)')';
TR_grid2 = TR_grid2 + xyz(iatom, :);


%%%%% get the VC of iatom for system 1 %%%%%
Idx1 = knnsearch(xyz, grid1);
iatomVC_Idx1 = find(Idx1 == iatom); % iatomVC_Idx1: index for iatom
len1 = length(iatomVC_Idx1);
% only retain the points within cutoff.
icount = 0;
for i = 1:len1
    pt_index = iatomVC_Idx1(i);
    in_sphere = atom_sphere(grid1(pt_index,:), xyz(iatom,:), cutoff);
    if ( in_sphere )
        icount = icount + 1;
        temp(icount) = pt_index;
    end
end
clear iatomVX_Idx1
iatomVX_Idx1 = temp;
len1 = length(iatomVX_Idx1);


%%%%% get the VC of iatom for system II %%%%%
Idx2 = knnsearch(rXYZ, grid2);
iatomVC_Idx2 = find(Idx2 == iatom);
len2 = length(iatomVC_Idx2);
% only retain the points within cutoff.
icount = 0;
for i = 1:len2
    pt_index = iatomVC_Idx2(i);
    in_sphere = atom_sphere(grid2(pt_index,:), rXYZ(iatom,:), cutoff); %%
    %in_sphere = atom_sphere(TR_grid2(pt_index,:), rXYZ(iatom,:), cutoff);
    if ( in_sphere )
        icount = icount + 1;
        temp2(icount) = pt_index;
    end
end
clear iatomVX_Idx2
iatomVX_Idx2 = temp2;
len2 = length(iatomVX_Idx2);


% loop over all pts (TR_gird2) of the VC of iatom in system2
% check if pt is also VC of iatom for system1?
% yes -- get the closet VC point of iatom form system 1
% no -- set pt to -1;
assigned = zeros([nfft,1]);
dista = zeros(1, len2);
reg = zeros(1, len2);
nreg = 0;
testF = 0;      % how many overlapping grid points
max_distance = -1;
fprintf('system 1 -> number of points in the VC of iatom: %d\n',length(iatomVX_Idx1));
fprintf('system 2 -> number of points in the VC of iatom: %d\n',length(iatomVX_Idx2));
fprintf('registering points in system I ...\n')

dx = box_x/nX;
dy = box_y/nY;
dz = box_z/nZ;

for j = 1:len2
    reg(j) = -1;
    pt2 = TR_grid2(iatomVX_Idx2(j), :);
    at = knnsearch(xyz, pt2);
    in_sphere = atom_sphere(pt2, xyz(iatom,:), cutoff);
    
    % test if this point from system 2 is in the VC of system 1 for iatom
    if (at == iatom && in_sphere)
        testF = testF + 1;
        % find the nearest point in the VC of system I (have not
        % assinged yet) to this point j.
        
        ix = floor(pt2(1)/dx);
        iy = floor(pt2(2)/dy);
        iz = floor(pt2(3)/dz);        
        
        old_dist = 99999;
        nb = 5;
        found_match = false;
        for i1=max(1,ix-nb):min(ix+nb,nX)
            for i2=max(1,iy-nb):min(iy+nb,nY)
                for i3=max(1,iz-nb):min(iz+nb,nZ)
                    jj = 1+(i1-1)+nX*(i2-1)+nX*nY*(i3-1);
                    if assigned(jj)==0
                        dist = norm(grid1(jj,:)-pt2);
                        if old_dist>dist
                            old_dist = dist;
                            found_match = true;
                            index_closest = jj;
                        end
                    end
                end
            end
        end
        
        if (found_match==false) 
            fprintf('found_match is false! stop\n')
            stop
        end
        
        assigned(index_closest) = 1;  % remove that point in system I
        pt1 = grid1(index_closest,:); % system I's point to be registered
        if old_dist > max_distance
            max_distance = old_dist;
        end
        
        % test if the system I point is in the VC
        atom1 = knnsearch(xyz, pt1);
        in_sphere = atom_sphere(pt1, xyz(iatom,:), cutoff);
        if (atom1==iatom && in_sphere)
            nreg = nreg + 1;
            reg(j) = index_closest;
            dista(j) = old_dist;
        else
            reg(j) = -1;
            dista(j) = 0;
        end
    end
end

fprintf('number of system II points inside the VC of system 1: %d\n',testF);
fprintf('number of registered points: %d\n',nreg);
fprintf('registration rate: %f %%. \n',nreg/(testF)*100);
fprintf('max distance between points in I and II: %f\n',max_distance);

if (max_distance>0.5)
    fprintf('max_distance > 0.5 too large! stop\n')
    stop
end


% %%%%%%%%%%%% plot system I and TR system II points together %%%%%%%%%%%%
% figure
% hold on
% plot3(xyz(:, 1), xyz(:, 2), xyz(:, 3), 'ro','MarkerSize',15,'MarkerFaceColor','r')
% plot3(xyz(iatom, 1), xyz(iatom, 2), xyz(iatom, 3), 'ko','MarkerSize',15,'MarkerFaceColor','k')
% for i = 1:length(reg)
%     if reg(i) == -1
%         continue
%     else
%         % system I
%         plot3(grid1(reg(i), 1), grid1(reg(i), 2), grid1(reg(i), 3), 'k.')
%         % system II
%         plot3(TR_grid2(iatomVX_Idx2(i),1),TR_grid2(iatomVX_Idx2(i),2),TR_grid2(iatomVX_Idx2(i),3),'b.')
%         % line segment connect I and II points.
%         line_x = [grid1(reg(i), 1), TR_grid2(iatomVX_Idx2(i),1)];
%         line_y = [grid1(reg(i), 2), TR_grid2(iatomVX_Idx2(i),2)];
%         line_z = [grid1(reg(i), 3), TR_grid2(iatomVX_Idx2(i),3)];
%         plot3(line_x,line_y,line_z,'r-')
%     end
% end
% hold off
% xlim([0, box_x]);
% ylim([0, box_y]);
% zlim([0, box_z]);
% 
% 
% 
% %%%%%%%%%%%% plot system I and un-rotated system II points together %%%%%%%%%%%%
% figure
% hold on
% plot3(xyz(:, 1),  xyz(:, 2),   xyz(:, 3), 'ro','MarkerSize',10,'MarkerFaceColor','r')
% plot3(xyz(iatom, 1),  xyz(iatom, 2),   xyz(iatom, 3), 'ro','MarkerSize',15,'MarkerFaceColor','r')
% plot3(rXYZ(:, 1), rXYZ(:, 2), rXYZ(:, 3), 'bo','MarkerSize',10,'MarkerFaceColor','b')
% plot3(rXYZ(iatom, 1), rXYZ(iatom, 2), rXYZ(iatom, 3), 'bo','MarkerSize',15,'MarkerFaceColor','b')
% for i = 1:length(reg)
%     if reg(i) == -1
%         continue
%     else
%         % system I
%         plot3(grid1(reg(i), 1), grid1(reg(i), 2), grid1(reg(i), 3), 'k.')
%         % system II
%         plot3(grid2(iatomVX_Idx2(i),1),grid2(iatomVX_Idx2(i),2),grid2(iatomVX_Idx2(i),3),'b.')
%     end
% end
% hold off
% xlim([0, box_x]);
% ylim([0, box_y]);
% zlim([0, box_z]);


%[fid, msg] = fopen(sprintf('atom_%d.txt', iatom),'wt');
for i = 1:length(reg)
    if (reg(i) ~= -1)
        grid_reg(iatomVX_Idx2(i)) = reg(i);
        distance(iatomVX_Idx2(i)) = dista(i);
        %fprintf(fid,'%d \t %d\n', iatomVX_Idx2(i), reg(i));
    end
end
%fclose(fid);

end