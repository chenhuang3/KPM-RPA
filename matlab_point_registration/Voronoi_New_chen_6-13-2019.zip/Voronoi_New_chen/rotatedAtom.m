clc; clear; close all;

global natom xyz rXYZ iatom natom_cluster buf_atoms box_x box_y box_z nX nY nZ atom_cutoff

% import atoms coord from txt file
%A = importdata('xangst1.txt');
%B = importdata('xangst2.txt');

A = importdata('xangst1_two_atom.txt');
B = importdata('xangst2_two_atom.txt');


% flag the points outside the R_radius
atom_cutoff = 4.0;

% config FFT grid points
box_x = 14.0;
box_y = 10.0;
box_z = 14.0;

% FFT mesh division from the abinit log file
nX = 80;
nY = 60;
nZ = 80;


%=================================================================
%================== no user input after this line ================
%=================================================================

fprintf('atom_cutoff: %f angstrom\n\n',atom_cutoff)
fprintf('nX: %d   nY: %d   nZ:%d\n\n',nX,nY,nZ)
fprintf('box_x: %f  box_y: %f  box_z:%f angstrom \n\n',box_x,box_y,box_z)

type  = A(:,1);          % atom type
x1_cop = A(:, 2);        % x-component of atoms
y1_cop = A(:, 3);        % y-component of atoms
z1_cop = A(:, 4);        % z-component of atoms

x2_cop = B(:, 2);        % x-component of atoms
y2_cop = B(:, 3);        % y-component of atoms
z2_cop = B(:, 4);        % z-component of atoms

% Some atom variables
natom = length(x1_cop);

% xyz: the coord for atoms
xyz = zeros(natom, 3); % 2: 2-dim
xyz(:, 1) = x1_cop;
xyz(:, 2) = y1_cop;
xyz(:, 3) = z1_cop;
fprintf('\natoms in system I: \n')
xyz

rXYZ = zeros(natom, 3); % 2: 2-dim
rXYZ(:, 1) = x2_cop;
rXYZ(:, 2) = y2_cop;
rXYZ(:, 3) = z2_cop;
fprintf('\natoms in system II: \n')
rXYZ


% how many voronoi region
reg = natom;
nfft = nX*nY*nZ;

grid_spacing_x = box_x/nX;
grid_spacing_y = box_y/nY;
grid_spacing_z = box_z/nZ;

% set grid, following the FORTRAN format
fprintf('making grid1 and grid2 in FORTRAN format ...\n')
grid1 = zeros([nfft,3]);
idx = 0;
for iz=1:nZ
    for iy=1:nY
        for ix=1:nX
            idx = idx + 1;
            grid1(idx,1) = (ix-1)*grid_spacing_x;
            grid1(idx,2) = (iy-1)*grid_spacing_y;
            grid1(idx,3) = (iz-1)*grid_spacing_z;
        end
    end
end
grid2 = grid1;


% check if box's boundaries are beyond the cutoff
for ia=1:natom
    % upper boundary
    if xyz(ia,1)+atom_cutoff>box_x
        fprintf('atom %d is too close to box boundary within cutoff\n',ia)
        stop
    end
    if xyz(ia,2)+atom_cutoff>box_y
        fprintf('atom %d is too close to box boundary within cutoff\n',ia)
        stop
    end
    if xyz(ia,3)+atom_cutoff>box_z
        fprintf('atom %d is too close to box boundary within cutoff\n',ia)
        stop
    end
    
    % lower boundary
    for ii=1:3
        if xyz(ia,ii)-atom_cutoff<0
            fprintf('atom %d is too close to box boundary within cutoff\n',ia)
            stop
        end
    end
end
fprintf('all atoms are away from the boundaries by cutoff. check passed \n')


% reg for grid2 index
grid_reg = zeros(1, nfft);
grid_reg(:) = -1;
distance = zeros(1, nfft);
grid_reg_Idx = 1:1:nfft;

% Find k-nearest neighbors by using xyz and grid1 points
Idx1 = knnsearch(xyz, grid1);
Idx2 = knnsearch(rXYZ, grid2);
Idx2_List(:) = Idx2;


% flag the points outside the atom_cutoff for system 1
for j = 1:nfft
    x1 = grid1(j, 1);
    y1 = grid1(j, 2);
    z1 = grid1(j, 3);
    atom_index = Idx1(j);
    x_atom = xyz(atom_index, 1);
    y_atom = xyz(atom_index, 2);
    z_atom = xyz(atom_index, 3);
    dist = sqrt((x1-x_atom)^2 + (y1-y_atom)^2 + (z1-z_atom)^2);
    if (dist > atom_cutoff )
        Idx1(j) = -1;
    end
end


% Plot system 1
figure(1)
plot3(xyz(:, 1), xyz(:, 2), xyz(:,3), 'r*','MarkerSize', 12)
hold on
for k = 1:reg
    if k==1; color='r'; end
    if k==2; color='b'; end
    if k==3; color='y'; end
    if k==4; color='m'; end
    if k==5; color='c'; end
    if k==6; color='k'; end
    if k==7; color='g'; end
    if k==8; color=[0.2 0.4 0.1]; end
    plot3(grid1(Idx1(:)==k, 1), grid1(Idx1(:)==k, 2), grid1(Idx1(:)==k, 3), ...
        '.', 'Color', color, 'MarkerSize', 8);
    hold on;
end
hold off
title('System I')
xlim([0, box_x])
ylim([0, box_y])
zlim([0, box_z]);


% flag the points outside the atom_cutoff for system 2
for j = 1:nfft
    x2 = grid2(j, 1);
    y2 = grid2(j, 2);
    z2 = grid2(j, 3);
    atom_index = Idx2(j);
    x_atom = rXYZ(atom_index, 1);
    y_atom = rXYZ(atom_index, 2);
    z_atom = rXYZ(atom_index, 3);
    dist = sqrt((x2-x_atom)^2 + (y2-y_atom)^2 + (z2-z_atom)^2);
    if (dist > atom_cutoff )
        Idx2(j) = -1;
    end
end


% Plot system 2
figure(2)
plot3(rXYZ(:, 1), rXYZ(:, 2), rXYZ(:,3), 'r*','MarkerSize', 12)
hold on
for k = 1:reg
    if k==1; color='r'; end
    if k==2; color='b'; end
    if k==3; color='y'; end
    if k==4; color='m'; end
    if k==5; color='c'; end
    if k==6; color='k'; end
    if k==7; color='g'; end
    if k==8; color=[0.2 0.4 0.1]; end
    plot3(grid2(Idx2(:)==k, 1), grid2(Idx2(:)==k, 2), grid2(Idx2(:)==k, 3), ...
        '.', 'Color', color, 'MarkerSize', 8);
    hold on;
end
hold off
title('System II')
xlim([0, box_x])
ylim([0, box_y])
zlim([0, box_z]);


% Plot Each atom for system I and II
% for k = 1:reg
%     %     if k==1; color='r'; end
%     %     if k==2; color='b'; end
%     %     if k==3; color='y'; end
%     %     if k==4; color='m'; end
%     %     if k==5; color='c'; end
%     %     if k==6; color='k'; end
%     %     if k==7; color='g'; end
%     %     if k==8; color=[0.2 0.4 0.1]; end
%     figure(3+k)
%     subplot(1, 2, 1);
%     plot3(xyz(:, 1), xyz(:, 2), xyz(:,3), 'r*','MarkerSize', 12)
%     hold on
%     plot3(grid1(Idx1(:)==k, 1), grid1(Idx1(:)==k, 2), grid1(Idx1(:)==k, 3), ...
%         'k.', 'MarkerSize', 8);
%     title('System I')
%
%     subplot(1, 2, 2);
%     plot3(rXYZ(:, 1), rXYZ(:, 2), rXYZ(:,3), 'r*','MarkerSize', 12)
%     hold on
%     plot3(grid2(Idx2(:)==k, 1), grid2(Idx2(:)==k, 2), grid2(Idx2(:)==k, 3), ...
%         'k.', 'MarkerSize', 8);
%     title('System II')
% end
% hold off
% xlim([0, box_x]);
% ylim([0, box_y]);
% zlim([0, box_z]);


%===============================
% loop over all atoms
%===============================
for i = 1:natom
    iatom = i;  % set the iatom which is shared by cost_func_angle()
    fprintf('\n\n===== working on atom %d ======',iatom)
    
    % get the clusters for system I and II
    k = 0;
    buf_atoms = [];
    for j = 1:natom
        if i == j
            continue
        end
        
        %dist1 = norm(xyz(iatom,:)-xyz(j,:));
        %dist2 = norm(rXYZ(iatom,:)-rXYZ(j,:));
        dist1 = norm(xyz(i, :)-xyz(j,:));
        dist2 = norm(rXYZ(i, :)-rXYZ(j,:));
        
        type1 = type(i);
        type2 = type(j);
        bth = bond_threshold(type1, type2);
        
        if (dist1<=bth && dist2<=bth)
            k = k + 1;
            buf_atoms(k) = j;
        else
            continue
        end
    end
    buf_atoms
    natom_cluster = length(buf_atoms);
    
    if (natom_cluster>=1)
        lowestCost = 1000000;
        for gamma=-pi:2*pi/20:pi
            for beta = -pi:2*pi/20:pi
                for alpha=-pi:2*pi/20:pi
                    c = cost_func_angle([alpha, beta, gamma]);
                    if c < lowestCost
                        lowestCost = c;
                        alpha0 = alpha;
                        beta0 = beta;
                        gamma0 = gamma;
                    end
                end
            end
        end
        opt = optimset('Display', 'final');
        [xopt] = fminsearch(@cost_func_angle,[alpha0,beta0,gamma0], opt);
        fprintf('Rotation angles: %f %f %f (rad)\n',xopt(1),xopt(2),xopt(3));
        fprintf('cost function: %f\n',cost_func_angle(xopt));
    else
        % this atom has no buffer atoms, just set the angle to [0 0 0]
        xopt = [0 0 0];
    end
    
    % rotate your voronoi cells for iatom
    [grid_reg, distance] = point_set_reg(nX, nY, nZ, nfft, box_x, box_y, box_z, iatom, ...
        xopt, xyz, rXYZ, grid1, grid2, atom_cutoff, grid_reg, distance);
end

grid_reg_output = [grid_reg_Idx; grid_reg; Idx2_List; distance];
fileID = fopen('grid_reg.txt','w');
fprintf(fileID,'%d \t %d \t %d \t %f\n', grid_reg_output);
fclose(fileID);

figure
plot(distance)

reg_num = 0;
for k = 1: nfft
    if(grid_reg(k) ~= -1)
        reg_num = reg_num+1;
    end
end
reg_num





