function [r] = atom_sphere(pt, atom_coord, cutoff)

dist = sqrt(...
    (pt(1)-atom_coord(1))^2 + ...
    (pt(2)-atom_coord(2))^2 + ...
    (pt(3)-atom_coord(3))^2);

if (dist > cutoff )
    r = false;
else
    r = true;
end

end